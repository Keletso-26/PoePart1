/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package poepart3;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author Student
 */
public class PoePart3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
 
   
        Login register = new Login();
        Message msg = new Message();

        JOptionPane.showMessageDialog(
                null,
                "====== Register ======",
                "Registration",
                JOptionPane.INFORMATION_MESSAGE
        );

        String name = JOptionPane.showInputDialog(null, "Please enter the username.");
        if (name == null) {
            return;
        }

        String password = JOptionPane.showInputDialog(null, "Please enter the password.");
        if (password == null) {
            return;
        }

        String cellphone = JOptionPane.showInputDialog(null, "Please enter the cellphone.");
        if (cellphone == null) {
            return;
        }

        JOptionPane.showMessageDialog(null, register.registerUser(name, password, cellphone));
        if (!register.registerStatus(name, password, cellphone)) {
            return;
        }

        JOptionPane.showMessageDialog(
                null,
                "===== Login =====",
                "Login",
                JOptionPane.INFORMATION_MESSAGE
        );

        String loginUsername = JOptionPane.showInputDialog(null, "Enter username to login");
        String loginPassword = JOptionPane.showInputDialog(null, "Enter password to login");

        if (loginUsername == null || loginPassword == null) {
            return;
        }

        boolean status = register.loginUser(loginUsername, loginPassword);
        JOptionPane.showMessageDialog(null, register.returnLoginStatus(status));

        if (status) {
            int option;
            do {
                String menu = """
                              ===== Select any of the option below =====
                              1. Send message
                              2. Message Management
                              3. Exit
                              Select an option: """;

                String input = JOptionPane.showInputDialog(
                        null,
                        menu,
                        "Main menu",
                        JOptionPane.QUESTION_MESSAGE
                );

                if (input == null) {
                    option = 3;
                } else {
                    try {
                        option = Integer.parseInt(input.trim());
                        switch (option) {
                            case 1 -> msg.sendingMessages();
                            case 2 -> msg.messageManagementMenu();
                            case 3 -> JOptionPane.showMessageDialog(null, "Goodbye");
                            default -> JOptionPane.showMessageDialog(
                                    null,
                                    "Invalid option!!",
                                    "Error",
                                    JOptionPane.ERROR_MESSAGE
                            );
                        }
                    } catch (NumberFormatException error) {
                        option = 0; // stays in loop so user can try again
                        JOptionPane.showMessageDialog(
                                null,
                                "Please enter a valid number",
                                "Input error",
                                JOptionPane.WARNING_MESSAGE
                        );
                    }
                }
            } while (option != 3);
        }
    }
}

class Registration {
    String userName;
    String passWord;
    String cellphone;

    public boolean checkUserName(String username) {
        return username != null && username.contains("_") && username.length() <= 5;
    }

    public boolean checkPasswordComplexity(String password) {
        return password != null
                && password.length() >= 8
                && password.matches(".*[A-Z].*")
                && password.matches(".*[a-z].*")
                && password.matches(".*\\d.*")
                && password.matches(".*[^a-zA-Z0-9].*");
    }

    public boolean checkCellPhoneNumber(String cellphone) {
        return cellphone != null
                && (cellphone.matches("^\\+27[0-9]{9}$") || cellphone.matches("^0[0-9]{9}$"));
    }

    public String registerUser(String username, String password, String cellphone) {
        if (checkUserName(username) && checkPasswordComplexity(password) && checkCellPhoneNumber(cellphone)) {
            this.userName = username;
            this.passWord = password;
            this.cellphone = cellphone;
            return "Registration was a success";
        } else {
            return "Registration was unsuccessful";
        }
    }

    public boolean registerStatus(String username, String password, String cellphone) {
        return checkUserName(username)
                && checkPasswordComplexity(password)
                && checkCellPhoneNumber(cellphone);
    }
}

class Login extends Registration {
    public boolean loginUser(String name, String password) {
        return name != null && password != null
                && name.equals(userName) && password.equals(passWord);
    }

    public String returnLoginStatus(boolean loginStatus) {
        if (loginStatus) {
            return "Login success";
        } else {
            return "Login failed";
        }
    }
}

class Message {
    ArrayList<String> sentMessages = new ArrayList<>();
    ArrayList<String> messageIdsList = new ArrayList<>();
    HashSet<String> messageIds = new HashSet<>();
    ArrayList<String> msgHash = new ArrayList<>();
    ArrayList<String> recipientNumber = new ArrayList<>();
    ArrayList<String> messageStatus = new ArrayList<>();
    ArrayList<String> disregardedMessages = new ArrayList<>();
    ArrayList<String> storedMessages = new ArrayList<>();
    ArrayList<String> senders = new ArrayList<>();

    Random random = new Random();
    Scanner scanner = new Scanner(System.in);

    int numMessageSent = 0;

    private int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = scanner.nextLine().trim();
            try {
                return Integer.parseInt(line);
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }
    }

    public void sendingMessages() {
        int numberOfMessages;

        while (true) {
            String answer = JOptionPane.showInputDialog(
                    null,
                    "How many messages do you want to send?",
                    "Send Messages",
                    JOptionPane.QUESTION_MESSAGE
            );

            if (answer == null) {
                return;
            }

            try {
                numberOfMessages = Integer.parseInt(answer.trim());
                if (numberOfMessages < 1) {
                    JOptionPane.showMessageDialog(
                            null,
                            "Please enter a number greater than 0",
                            "Error",
                            JOptionPane.ERROR_MESSAGE
                    );
                    continue;
                }
                break;
            } catch (NumberFormatException error) {
                JOptionPane.showMessageDialog(
                        null,
                        "Please enter a valid number",
                        "Error",
                        JOptionPane.ERROR_MESSAGE
                );
            }
        }

        for (int i = 1; i <= numberOfMessages; i++) {
            System.out.println("==============================");
            System.out.println("MESSAGE " + i);
            System.out.println("==============================");
            String messageID = generateMessageID();

            System.out.print("Enter recipient cell number: ");
            String recipient = scanner.nextLine().trim();
            String recipientResult = checkRecipientCell(recipient);
            if (!recipientResult.equals("Valid number")) {
                System.out.println(recipientResult);
                i--;
                continue;
            }

            System.out.print("Enter your message: ");
            String messageText = scanner.nextLine();
            if (messageText.length() > 250 || messageText.trim().isEmpty()) {
                System.out.println("Please enter a message of 1 to 250 characters.");
                i--;
                continue;
            }

            System.out.print("Enter sender name: ");
            String sender = scanner.nextLine();

            int messageNumber = sentMessages.size() + 1;
            String messageHash = createMessageHash(messageID, messageNumber, messageText);

            msgHash.add(messageHash);
            sentMessages.add(messageText);
            messageIdsList.add(messageID);
            messageIds.add(messageID);
            recipientNumber.add(recipient);
            senders.add(sender);

            String status = SentMessage();
            if (!status.equals("Deleted")) {
                messageStatus.add(status);
            }
            if (status.equals("Sent")) {
                numMessageSent++;
            }
        }

        printMessages();
        System.out.println("Total messages sent: " + returnTotalMessages());
    }

    public int returnTotalMessages() {
        return numMessageSent;
    }

    public String createMessageHash(String messageID, int messageNumber, String messageText) {
        String firstTwoNumbers = messageID.substring(0, 2);
        String cleanMessage = messageText.trim();
        String[] words = cleanMessage.split("\\s+");
        String firstWord = words[0];
        String lastWord = words[words.length - 1];
        String hash = firstTwoNumbers + ":" + messageNumber + ":" + firstWord + lastWord;
        return hash.toUpperCase();
    }

    public String generateMessageID() {
        String messageID;
        do {
            long number = 1000000000L + Math.floorMod(random.nextLong(), 9000000000L);
            messageID = String.valueOf(number);
        } while (messageIds.contains(messageID));
        return messageID;
    }

    public String checkRecipientCell(String cellphone) {
        if (cellphone.matches("^\\+27[0-9]{9}$") || cellphone.matches("^0[0-9]{9}$")) {
            return "Valid number";
        } else {
            return "Invalid number";
        }
    }

    public String SentMessage() {
        System.out.println("Choose what you want to do with this message!");
        System.out.println("1. Send");
        System.out.println("2. Disregard");
        System.out.println("3. Store");
        int choice = readInt("Enter your choice: ");

        int lastIndex = sentMessages.size() - 1;

        switch (choice) {
            case 1 -> {
                System.out.println("Message successfully sent");
                return "Sent";
            }
            case 2 -> {
                int deleteChoice = readInt("Press 0 to delete the message: ");
                if (deleteChoice == 0) {
                    System.out.println("Message deleted");
                    disregardedMessages.add(sentMessages.get(lastIndex));
                    String messageID = messageIdsList.get(lastIndex);
                    messageIds.remove(messageID);
                    recipientNumber.remove(lastIndex);
                    sentMessages.remove(lastIndex);
                    msgHash.remove(lastIndex);
                    messageIdsList.remove(lastIndex);
                    senders.remove(lastIndex);
                    return "Deleted";
                } else {
                    System.out.println("Invalid option!");
                    return "Disregarded";
                }
            }
            case 3 -> {
                storedMessages.add(sentMessages.get(lastIndex));
                System.out.println("Message successfully stored");
                return "Stored";
            }
            default -> {
                System.out.println("Invalid option");
                return "Disregarded";
            }
        }
    }

    public String printMessages() {
        StringBuilder allMessages = new StringBuilder();
        System.out.println("===== All Messages =====");
        for (int i = 0; i < sentMessages.size(); i++) {
            int messageNumber = i + 1;
            String status = i < messageStatus.size() ? messageStatus.get(i) : "Unknown";

            allMessages.append("Message Number: ").append(messageNumber).append("\n");
            allMessages.append("Message ID: ").append(messageIdsList.get(i)).append("\n");
            allMessages.append("Recipient: ").append(recipientNumber.get(i)).append("\n");
            allMessages.append("Message: ").append(sentMessages.get(i)).append("\n");
            allMessages.append("Message Hash: ").append(msgHash.get(i)).append("\n");
            allMessages.append("Status: ").append(status).append("\n\n");

            System.out.println("==============================");
            System.out.println("Message Number: " + messageNumber);
            System.out.println("Message ID: " + messageIdsList.get(i));
            System.out.println("Recipient: " + recipientNumber.get(i));
            System.out.println("Message: " + sentMessages.get(i));
            System.out.println("Message Hash: " + msgHash.get(i));
            System.out.println("Status: " + status);
        }
        return allMessages.toString();
    }

    public void messageManagementMenu() {
        while (true) {
            System.out.println();
            System.out.println("1. Show disregarded messages");
            System.out.println("2. Show all stored messages");
            System.out.println("3. Delete a message by Hash Id");
            System.out.println("4. Display full report");
            System.out.println("5. Search for a message");
            System.out.println("6. Display the longest message");
            System.out.println("7. Back to menu");
            System.out.print("Choose an option (1-7): ");
            String option = scanner.nextLine().trim();
            switch (option) {
                case "1" -> showDisregardedMessages();
                case "2" -> showAllStoredMessages();
                case "3" -> deleteMessageByHash();
                case "4" -> displayFullReport();
                case "5" -> searchMessageByHashID();
                case "6" -> findLongestMessage();
                case "7" -> {
                    return;
                }
                default -> System.out.println("Invalid choice.");
            }
        }
    }

    public void findLongestMessage() {
        if (sentMessages.isEmpty()) {
            System.out.println("No sent message to analyze the longest");
            return;
        }
        int maxLength = -1;
        int index = -1;
        for (int i = 0; i < sentMessages.size(); i++) {
            int currentLength = sentMessages.get(i).length();
            if (currentLength > maxLength) {
                maxLength = currentLength;
                index = i;
            }
        }
        if (index != -1) {
            System.out.println();
            System.out.println("====== LONGEST MESSAGE SENT ======");
            System.out.println("Length: " + maxLength + " characters long");
            System.out.println("Hash ID: " + msgHash.get(index));
            System.out.println("Message ID: " + messageIdsList.get(index));
            System.out.println("From: " + senders.get(index));
            System.out.println("To: " + recipientNumber.get(index));
            System.out.println("Message: " + sentMessages.get(index));
        }
    }

    public void showDisregardedMessages() {
        if (disregardedMessages.isEmpty()) {
            System.out.println("No deleted messages yet.");
            return;
        }
        System.out.println();
        System.out.println("====== Deleted Messages ======");
        for (int i = 0; i < disregardedMessages.size(); i++) {
            System.out.println((i + 1) + ". " + disregardedMessages.get(i));
        }
    }

    public void showAllStoredMessages() {
        if (storedMessages.isEmpty()) {
            System.out.println("No stored messages to display");
            return;
        }
        System.out.println();
        System.out.println("========== All stored messages ==========\n");
        for (int i = 0; i < storedMessages.size(); i++) {
            System.out.println((i + 1) + ". " + storedMessages.get(i));
        }
    }

    public void deleteMessageByHash() {
        if (sentMessages.isEmpty()) {
            System.out.println("No messages to delete.");
            return;
        }
        System.out.print("Enter hash ID to delete: ");
        String hash = scanner.nextLine().trim();
        int index = findHashIndex(hash);
        if (index != -1) {
            disregardedMessages.add(sentMessages.get(index));
            messageIds.remove(messageIdsList.get(index));

            if (index < messageStatus.size()) {
                if (messageStatus.get(index).equals("Sent")) {
                    numMessageSent--;
                }
                messageStatus.remove(index);
            }
            sentMessages.remove(index);
            senders.remove(index);
            recipientNumber.remove(index);
            messageIdsList.remove(index);
            msgHash.remove(index);
            System.out.println("Message deleted and moved to disregarded");
        } else {
            System.out.println("Message not found");
        }
    }

    public void displayFullReport() {
        if (sentMessages.isEmpty()) {
            System.out.println("No sent messages to display.");
            return;
        }
        System.out.println();
        System.out.println("========== Full Message Report ===========\n");

        System.out.printf("| %-5s | %-15s | %-15s | %-20s | %-12s | %-10s |%n",
                "No.",
                "Sender",
                "Recipient",
                "Message",
                "Message ID",
                "Hash ID"
        );

        for (int i = 0; i < sentMessages.size(); i++) {
            String message = sentMessages.get(i);
            if (message.length() > 20) {
                message = message.substring(0, 17) + "...";
            }

            System.out.printf("| %-5d | %-15s | %-15s | %-20s | %-12s | %-10s |%n",
                    i + 1,
                    senders.get(i),
                    recipientNumber.get(i),
                    message,
                    messageIdsList.get(i),
                    msgHash.get(i)
            );
        }

        System.out.println();
        System.out.println("Total Sent messages: " + sentMessages.size());
        System.out.println("Total Disregarded Messages: " + disregardedMessages.size());
        System.out.println("Total Stored Messages: " + storedMessages.size());
    }

    public void searchMessageByHashID() {
        if (sentMessages.isEmpty()) {
            System.out.println("No sent messages to search");
            return;
        }
        System.out.print("Enter the HashID to search: ");
        String hashId = scanner.nextLine().trim();

        if (hashId.isEmpty()) {
            System.out.println("Hash ID cannot be empty.");
            return;
        }

        int index = findHashIndex(hashId);

        if (index == -1) {
            System.out.println("No message exists with this Hash ID: " + hashId);
            return;
        }

        System.out.println();
        System.out.println("======== Message Details =========\n");
        System.out.println("Hash ID: " + msgHash.get(index));
        System.out.println("Message ID: " + messageIdsList.get(index));
        System.out.println("From: " + senders.get(index));
        System.out.println("To: " + recipientNumber.get(index));
        System.out.println("Message: " + sentMessages.get(index));
        System.out.println("Length: " + sentMessages.get(index).length() + " characters long");
    }

    private int findHashIndex(String hash) {
        for (int i = 0; i < msgHash.size(); i++) {
            if (msgHash.get(i).equalsIgnoreCase(hash)) {
                return i;
            }
        }
        return -1;
    }
}

